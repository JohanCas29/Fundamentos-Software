/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import model.Challenge;


/**
 *
 * @author BIBLIOTECA
 */
public class ChallengeController {
    private ArrayList<Challenge> ChallengeList;

    public ChallengeController() {
        ChallengeList= new ArrayList();
        
    }

    public ChallengeController(ArrayList<Challenge> ChallengeList) {
        this.ChallengeList = ChallengeList;
        toFillChallenges();
    }
    
    public void createChallenge(Challenge c){
        ChallengeList.add(c);
    }
    
    public Challenge findChallenge(int i){
        Challenge c= new Challenge();
        for (Challenge challenge : ChallengeList) {
            if(challenge.getIdChallenge()==i) c=challenge;
        }
        return c;
    }
    
    public void modifyChallenge(Challenge c){
        ChallengeList.set(ChallengeList.indexOf(c),c);
    }
    public void deleteChallenge(Challenge c){
        ChallengeList.remove(c);
    }
    private void toFillChallenges(){
        //ChallengeList.add(new Challenge(1,2000,teamList,1000,"JohanCas29","$1"));
    }
}
