/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import model.Team;

/**
 *
 * @author BIBLIOTECA
 */
public class TeamController {
    private ArrayList<Team> TeamList;

    public TeamController() {
        TeamList= new ArrayList();
        
    }

    public TeamController(ArrayList<Team> TeamList) {
        this.TeamList = TeamList;
        toFillTeams();
    }
    
    public void createTeam(Team t){
        TeamList.add(t);
    }
    
    public Team findTeam(int i){
        Team t= new Team();
        for (Team team : TeamList) {
            if(team.getIdTeam()==i) t=team;
        }
        return t;
    }
    
    public void modifyTeam(Team t){
        TeamList.set(TeamList.indexOf(t),t);
    }
    public void deleteTeam(Team t){
        TeamList.remove(t);
    }
    private void toFillTeams(){
        TeamList.add(new Team(1,"LHDJ",gamerList,2000,2,"JohanCas29"));
    
    }

    
}
    

