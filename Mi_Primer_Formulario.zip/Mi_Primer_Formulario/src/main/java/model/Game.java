/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author BIBLIOTECA
 */
public class Game {
    private int idGame;
    private String name;
    private String type;
    private int levels;
    private int amountGamers;
    private String goal;

    public Game() {
        idGame=0;
        name="Game"+idGame;
        type="Battle";
        levels=10;
        amountGamers=5;
        goal="To win the game";   
    }

    public int getIdGame() {
        return idGame;
    }

    public void setIdGame(int idGame) {
        this.idGame = idGame;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getLevels() {
        return levels;
    }

    public void setLevels(int levels) {
        this.levels = levels;
    }

    public int getAmountGamers() {
        return amountGamers;
    }

    public void setAmountGamers(int amountGamers) {
        this.amountGamers = amountGamers;
    }

    public String getGoal() {
        return goal;
    }

    public void setGoal(String goal) {
        this.goal = goal;
    }

    public Game(int idGame, String name, String type, int levels, int amountGamers, String goal) {
        this.idGame = idGame;
        this.name = name;
        this.type = type;
        this.levels = levels;
        this.amountGamers = amountGamers;
        this.goal = goal;
    }
    
    
    
    
}
