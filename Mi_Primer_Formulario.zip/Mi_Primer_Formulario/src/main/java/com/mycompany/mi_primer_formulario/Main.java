/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author LabingB101
 */
package com.mycompany.mi_primer_formulario;

import view.GamerPanel;

public class Main {

    public static void main(String[] args) {

        GamerPanel ventana = new GamerPanel();

        ventana.setVisible(true);
    }
}
