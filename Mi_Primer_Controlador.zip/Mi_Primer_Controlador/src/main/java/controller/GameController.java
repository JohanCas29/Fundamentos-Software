/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import model.Game;


/**
 *
 * @author BIBLIOTECA
 */
public class GameController {
        private ArrayList<Game> GameList;

    public GameController() {
        GameList= new ArrayList();
        
    }

    public GameController(ArrayList<Game> GameList) {
        this.GameList = GameList;
        toFillGames();
    }
    
    public void createGame(Game g){
        GameList.add(g);
    }
    
    public Game findGame(int i){
        Game g= new Game();
        for (Game game : GameList) {
            if(game.getIdGame()==i) g=game;
        }
        return g;
    }
    
    public void modifyGame(Game g){
        GameList.set(GameList.indexOf(g),g);
    }
    public void deleteGame(Game g){
        GameList.remove(g);
    }
    private void toFillGames(){
        //TeamList.add(new Team(1,"LHDJ",gamerList,"JohanCas29",6969,"Challenger1200lp"));
        //No se que llenar acá, llenar mas tarde...
    }
}
