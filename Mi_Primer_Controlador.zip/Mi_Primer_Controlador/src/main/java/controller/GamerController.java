/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import model.Gamer;

/**
 *
 * @author BIBLIOTECA
 */
public class GamerController {
    private ArrayList<Gamer> gamerList;

    public GamerController() {
        gamerList= new ArrayList();
        
    }

    public GamerController(ArrayList<Gamer> gamerList) {
        this.gamerList = gamerList;
        toFillGamers();
    }
    
    public void createGamer(Gamer g){
        gamerList.add(g);
    }
    
    public Gamer findGamer(int i){
        Gamer g= new Gamer();
        for (Gamer gamer : gamerList) {
            if(gamer.getIdGamer()==i) g=gamer;
        }
        return g;
    }
    
    public void modifyGamer(Gamer g){
        gamerList.set(gamerList.indexOf(g),g);
    }
    public void deleteGamer(Gamer g){
        gamerList.remove(g);
    }
    private void toFillGamers(){
        gamerList.add(new Gamer(1,"Johan Pardo","GordoPapeador67","JohanCas29",6969,"Challenger1200lp"));
        gamerList.add(new Gamer(2,"Kenan Diaz","FakerBoliviano","NoSe",0,"BolsaDeBasura"));
        gamerList.add(new Gamer(2,"Sebastian Gonzalez","KeKeSalchichon","ElSebastrosoyou",6767,"Challenger1999lp"));
    }
}