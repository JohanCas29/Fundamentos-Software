/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import java.util.ArrayList;
import model.Challenge;

/**
 *
 * @author BIBLIOTECA
 */
public class ChallengeController {
    private ArrayList<Challenge> ChallengeList;

    public ChallengeController() {
        ChallengeList= new ArrayList();
        
    }

    public ChallengeController(ArrayList<Challenge> ChallengeList) {
        this.ChallengeList = ChallengeList;
        toFillChallenges();
    }
    
    public void createChallenge(Challenge c){
        ChallengeList.add(c);
    }
    
    public Challenge findChallenge(int i){
        Challenge c= new Challenge();
        for (Challenge challenge : ChallengeList) {
            if(challenge.getIdChallenge()==i) c=challenge;
        }
        return c;
    }
    
    public void modifyChallenge(Challenge c){
        ChallengeList.set(ChallengeList.indexOf(c),c);
    }
    public void deleteChallenge(Challenge c){
        ChallengeList.remove(c);
    }
    private void toFillChallenges(){
        //TeamList.add(new Team(1,"LHDJ",gamerList,"JohanCas29",6969,"Challenger1200lp"));
        //No se que llenar acá, llenar mas tarde...
    }
}
