/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;
import java.util.Date;

/**
 *
 * @author BIBLIOTECA
 */
public class Challenge {
    private int idChallenge;
    private Date date;
    private ArrayList<Team> teamList;
    private int timeLimit;
    private Team winner;
    private String prize;

    public Challenge() {
        idChallenge=0;
        date = new Date();
        teamList= new ArrayList();
        timeLimit=5;
        winner= new Team();
        prize="67.000USD + International Challenge + 6.700Gold";
    }

    public Challenge(int idChallenge, Date date, ArrayList<Team> teamList, int timeLimit, Team winner, String prize) {
        this.idChallenge = idChallenge;
        this.date = date;
        this.teamList = teamList;
        this.timeLimit = timeLimit;
        this.winner = winner;
        this.prize = prize;
    }

    public int getIdChallenge() {
        return idChallenge;
    }

    public void setIdChallenge(int idChallenge) {
        this.idChallenge = idChallenge;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public ArrayList<Team> getTeamList() {
        return teamList;
    }

    public void setTeamList(ArrayList<Team> teamList) {
        this.teamList = teamList;
    }

    public int getTimeLimit() {
        return timeLimit;
    }

    public void setTimeLimit(int timeLimit) {
        this.timeLimit = timeLimit;
    }

    public Team getWinner() {
        return winner;
    }

    public void setWinner(Team winner) {
        this.winner = winner;
    }

    public String getPrize() {
        return prize;
    }

    public void setPrize(String prize) {
        this.prize = prize;
    }
    
    
}
