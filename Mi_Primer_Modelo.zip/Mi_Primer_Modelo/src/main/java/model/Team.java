/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.util.ArrayList;

/**
 *
 * @author BIBLIOTECA
 */
public class Team {
    private int idTeam;
    private String name;
    private ArrayList<Gamer> gamerList;
    private long score;
    private String level;
    private Gamer leader;

    public Team() {
        idTeam=0;
        name="Team"+idTeam;
        gamerList=new ArrayList();
        score=0;
        level="Amateur";
        leader= new Gamer();
    }

    public Team(int idTeam, String name, ArrayList<Gamer> gamerList, long score, String level, Gamer leader) {
        this.idTeam = idTeam;
        this.name = name;
        this.gamerList = gamerList;
        this.score = score;
        this.level = level;
        this.leader = leader;
    }
    
    

    
    
    
}
